// ==============================
// Main.js 

$(document).ready(function(){ 

	console.log('DOM READY');
});

 
$(window).load(function() {
 
  	console.log('HTML , CSS , JS , IMG READY');
});